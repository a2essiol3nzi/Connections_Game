package server.network;

import server.core.ActiveGame;
import server.core.GameManager;
import server.core.UserStore;
import protocol.GameEnded;

import java.io.IOException;
import java.util.Set;

/**
 * Scheduler della partita attiva. Ciclo: attende scadenza partita corrente 
 * -> finalizza (esiti+UserStore) -> persist event-driven (stat su disco
 * subito) -> ruota alla partita successiva -> invia la notifica UDP ai
 * partecipanti della partita appena conclusa.
 * Coordinazione via Thread.sleep fino a endTime (no wait/notify necessario).
 * Lo swap di ActiveGame avviene in GameManager.rotate (synchronized).
 * 
 * La notifica UDP (type: GAME_ENDED + gameId/roundId) è un segnale, non contiene
 * i risultati. La rotazione avviene prima dell'invio: il round notificato non è
 * più `current`, quindi requestGameInfo(roundId) / requestGameStats leggono
 * deterministicamente GameManager.history.
 */
public class GameScheduler implements Runnable {

    private final GameManager gameMan;
    private final UserStore users;
    private final UdpNotifier notifier;

    public GameScheduler(GameManager gm, UserStore users, UdpNotifier notifier) {
        this.gameMan = gm;
        this.users = users;
        this.notifier = notifier;
    }

    @Override
    public void run() {
        while (true) {
            ActiveGame g = gameMan.current();
            if (g == null) { 
                sleep(1000); // rallenta il polling / busy-wait 
                continue; 
            }
            long waitMs = g.endTimeMs - System.currentTimeMillis();
            if (waitMs > 0) 
                sleep(waitMs); // durata partita
            gameMan.finalizeGame(users);
            try {
                users.persistUsers(); // persist event-driven
                gameMan.persistHistory(); // persistenza storico partite su disco
            } catch (IOException e) {
                System.err.println("[Scheduler] persist failed: " + e.getMessage());
            }
            Set<Integer> parts = g.participants();
            gameMan.rotate(System.currentTimeMillis());
            notifier.notifyEnd(parts, new GameEnded("GAME_ENDED", g.gameId, g.roundId));
            System.out.println("[Scheduler] game " + g.gameId + " (round " + g.roundId + ") ended, " + parts.size() + " players");
        }
    }

    private static void sleep(long ms) {
        long deadline = System.currentTimeMillis() + ms;
        while (true) {
            long rem = deadline - System.currentTimeMillis();
            if (rem <= 0) return;
            try { Thread.sleep(rem); return; }
            catch (InterruptedException e) { /* retry */ }
        }
    }
}
